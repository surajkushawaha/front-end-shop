function registerUser(event) {
    event.preventDefault();

    // Fetch input values
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Validate if fields are not empty
    if (username.trim() === '' || email.trim() === '' || password.trim() === '') {
        alert('Please fill in all fields');
        return false;
    }

    // Save data to local storage (for demo purposes, you might want to use a backend for real applications)
    const userData = {
        username: username,
        email: email,
        password: password
    };
    localStorage.setItem('userData', JSON.stringify(userData));

    // Optionally, you can redirect to another page after successful registration
    // For demonstration, just show an alert
    alert('Registration successful!');

    // Clear form fields
    document.getElementById('registrationForm').reset();

    return true;
}
